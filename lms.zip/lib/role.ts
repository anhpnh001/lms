export const isTeacher = (userId?: string | null) => {
  return true
}
export const isAdmin = (userId?: string | null) => {
  return true
}
