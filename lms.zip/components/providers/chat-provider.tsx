'use client'
export function ChatProvider({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
